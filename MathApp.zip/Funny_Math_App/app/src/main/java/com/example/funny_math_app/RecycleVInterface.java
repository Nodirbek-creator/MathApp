package com.example.funny_math_app;

public interface RecycleVInterface {
    void onItemClick(int position);
}
