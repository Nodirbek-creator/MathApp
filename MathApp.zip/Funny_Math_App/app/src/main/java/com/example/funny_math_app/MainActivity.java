package com.example.funny_math_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements RecycleVInterface {

    ArrayList<MathTopic> mathTopicsModules = new ArrayList<>();
    int[] topic_images = {
            R.drawable.arithmetics,
            R.drawable.x_squared,
            R.drawable.root,
            R.drawable.function,
            R.drawable.arithmetic_progression,
            R.drawable.geometric_progression,
            R.drawable.quadratic_equation,
            R.drawable.high_algebra
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        RecyclerView recyclerView = findViewById(R.id.recycle_view);
        setUpMathTopicsModules();
        Adaptor adaptor = new Adaptor(this,mathTopicsModules,this);
        recyclerView.setAdapter(adaptor);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setUpMathTopicsModules(){
        String[] topic_name = getResources().getStringArray(R.array.topics_of_math);
        String[] grades = getResources().getStringArray(R.array.grades_of_topics);
        String[] description = getResources().getStringArray(R.array.description_of_topics);
        String[] example = getResources().getStringArray(R.array.examples);
        String[] question = getResources().getStringArray(R.array.questions);
        for (int i = 0; i < topic_name.length; i++) {
            mathTopicsModules.add(new MathTopic(topic_images[i], topic_name[i],grades[i],description[i],example[i],question[i] ));
        }
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(this, Details.class);

        intent.putExtra("TOPIC_NAME",mathTopicsModules.get(position).getTopic_name());
        intent.putExtra("GRADE",mathTopicsModules.get(position).getGrade());
        intent.putExtra("DESCRIPTION",mathTopicsModules.get(position).getDescription());
        intent.putExtra("EXAMPLE",mathTopicsModules.get(position).getExample());
        intent.putExtra("QUESTION",mathTopicsModules.get(position).getQuestion());
        intent.putExtra("IMAGE",mathTopicsModules.get(position).getImage());

        startActivity(intent);
    }
}