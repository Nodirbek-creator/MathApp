package com.example.funny_math_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adaptor extends RecyclerView.Adapter<Adaptor.MyViewHolder>{

    private final RecycleVInterface recycleVInterface;
    Context context;
    ArrayList<MathTopic> mathTopics;

    public Adaptor (Context context, ArrayList<MathTopic> mathTopicsModules,RecycleVInterface recycleVInterface){
        this.context = context;
        this.mathTopics = mathTopicsModules;
        this.recycleVInterface = recycleVInterface;
    }

    @NonNull
    @Override
    public Adaptor.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.cardview, parent,false);
        return new Adaptor.MyViewHolder(view, recycleVInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptor.MyViewHolder holder, int position) {
        holder.topic_name.setText(mathTopics.get(position).getTopic_name());
        holder.grade_name.setText(mathTopics.get(position).getGrade());
        holder.image.setImageResource(mathTopics.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return mathTopics.size();
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView image;
        TextView topic_name, grade_name;
        public MyViewHolder(@NonNull View itemView, RecycleVInterface recycleVInterface) {
            super(itemView);

            image = itemView.findViewById(R.id.topic_image);
            topic_name = itemView.findViewById(R.id.topic_name);
            grade_name = itemView.findViewById(R.id.grade);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (recycleVInterface != null){
                        int position = getAdapterPosition();

                        if(position != RecyclerView.NO_POSITION){
                            recycleVInterface.onItemClick(position);
                        }
                    }
                }
            });
        }

    }
}
