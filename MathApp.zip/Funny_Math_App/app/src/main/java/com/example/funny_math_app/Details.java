
package com.example.funny_math_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class Details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_details);
        String name = getIntent().getStringExtra("TOPIC_NAME");
        String grade = getIntent().getStringExtra("GRADE");
        String description = getIntent().getStringExtra("DESCRIPTION");
        String example = getIntent().getStringExtra("EXAMPLE");
        String question = getIntent().getStringExtra("QUESTION");
        int image = getIntent().getIntExtra("IMAGE",0);

        TextView gradeTV = findViewById(R.id.det_grade);
        TextView nameTV = findViewById(R.id.det_topic_name);
        TextView descriptionTV = findViewById(R.id.det_description);
        TextView exampleTV = findViewById(R.id.det_example_content);
        TextView questionTV = findViewById(R.id.det_question);
        ImageView imageView = findViewById(R.id.det_topic_img);

        gradeTV.setText(grade);
        nameTV.setText(name);
        descriptionTV.setText(description);
        exampleTV.setText(example);
        questionTV.setText(question);
        imageView.setImageResource(image);
    }
}