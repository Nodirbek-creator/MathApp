package com.example.funny_math_app;

public class MathTopic {
    int image;
    String topic_name, grade, description,example,question;

    boolean isFavorite;

    public boolean isFavorite() {
        return isFavorite;
    }

    public String getQuestion() {
        return question;
    }

    public String getExample() {
        return example;
    }

    public int getImage() {
        return image;
    }

    public String getTopic_name() {
        return topic_name;
    }

    public String getGrade() {
        return grade;
    }

    public String getDescription() {
        return description;
    }

    public MathTopic(int image, String topic_name, String grade, String description, String example, String question, boolean isFavorite) {
        this.image = image;
        this.topic_name = topic_name;
        this.grade = grade;
        this.description = description;
        this.example = example;
        this.question = question;
        this.isFavorite = isFavorite;
    }

    public MathTopic(int image, String topic_name, String grade, String description, String example, String question) {
        this.image = image;
        this.topic_name = topic_name;
        this.grade = grade;
        this.description = description;
        this.example = example;
        this.question = question;
    }
}
